// (Preview: The actual file is likely larger. Here is a typical structure.)
import Header from '../components/Header'

export default function HomePage() {
  return (
    <main>
      <Header />
      <h1>Welcome to Vivekananda School WebAI</h1>
      {/* Additional content */}
    </main>
  )
}