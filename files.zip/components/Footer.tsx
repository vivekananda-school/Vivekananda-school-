export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <span className="font-display text-2xl font-bold text-primary-600">
              Vivekananda
            </span>
            <p className="text-gray-600 text-sm">
              Empowering minds, Enriching futures. Building tomorrow's leaders today.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-900">Quick Links</h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <a href="/about" className="text-gray-600 hover:text-primary-600 text-sm">
                      About Us
                    </a>
                  </li>
                  <li>
                    <a href="/academics" className="text-gray-600 hover:text-primary-600 text-sm">
                      Academics
                    </a>
                  </li>
                  <li>
                    <a href="/admission" className="text-gray-600 hover:text-primary-600 text-sm">
                      Admissions
                    </a>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-gray-900">Contact</h3>
                <ul className="mt-4 space-y-4">
                  <li className="text-gray-600 text-sm">
                    <span className="block">123 Education Street</span>
                    <span className="block">New Delhi, India</span>
                  </li>
                  <li>
                    <a href="tel:+911234567890" className="text-gray-600 hover:text-primary-600 text-sm">
                      +91 123 456 7890
                    </a>
                  </li>
                  <li>
                    <a href="mailto:info@vivekananda.edu" className="text-gray-600 hover:text-primary-600 text-sm">
                      info@vivekananda.edu
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-200 pt-8">
          <p className="text-gray-500 text-sm text-center">
            © {new Date().getFullYear()} Vivekananda School. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}